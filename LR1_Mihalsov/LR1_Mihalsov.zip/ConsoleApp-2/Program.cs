﻿using System;
public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Введите свое имя"); 
        string st = Console.ReadLine();
        Console.WriteLine("Привет {0}",st);
        Console.ReadLine();
    }
}


