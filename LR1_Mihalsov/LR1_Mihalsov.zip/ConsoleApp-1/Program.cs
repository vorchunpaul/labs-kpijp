﻿class HelloWorld
{
    static void Main(string[] args)
    {
        System.Console.WriteLine("Изучаем язык С#");
    }
}

