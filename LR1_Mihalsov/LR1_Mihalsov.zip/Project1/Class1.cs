﻿using System.Windows.Forms;

class DialogDemo
{
    static void Main()
    {
        MessageBox.Show("Продолжаем изучать С#");
    }
}